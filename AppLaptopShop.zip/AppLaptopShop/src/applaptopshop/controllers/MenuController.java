package applaptopshop.controllers;

import applaptopshop.models.User;
import applaptopshop.views.CartView;
import applaptopshop.views.ListLaptopView;
import applaptopshop.views.ListOrderView;
import applaptopshop.views.LoginView;
import applaptopshop.views.ManageLaptopView;
import applaptopshop.views.MenuView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class MenuController {
    private final MenuView menuView;
    private final User user;

    public MenuController(MenuView menuView, User user) {
        this.menuView = menuView;
        this.user = user;
        this.menuView.addListener(new MenuListener());
        if(user.getPosition().equals("USER")){
            this.menuView.getBtnManageLaptop().setVisible(false);
            this.menuView.getLbHello().setText("Xin chào: " + user.getFullName());
        }else{
            this.menuView.getLbHello().setText("Xin chào: ADMIN - " + user.getFullName());
        }
    }
    
    class MenuListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == menuView.getBtnListLaptop()){
                menuView.dispose();
                ListLaptopView listLaptopView = new ListLaptopView();
                ListLaptopController listLaptopController = new ListLaptopController(listLaptopView, user);
                listLaptopView.setVisible(true);
            }else if(e.getSource() == menuView.getBtnCart()){
                menuView.dispose();
                CartView cartView = new CartView();
                CartController cartController = new CartController(cartView, user);
                cartView.setVisible(true);
            }else if(e.getSource() == menuView.getBtnOrder()){
                menuView.dispose();
                ListOrderView listOrderView = new ListOrderView();
                ListOrderController listOrderController = new ListOrderController(listOrderView, user);
                listOrderView.setVisible(true);
            }else if(e.getSource() == menuView.getBtnManageLaptop()){
                menuView.dispose();
                ManageLaptopView manageLaptopView = new ManageLaptopView();
                ManageLaptopController manageLaptopController = new ManageLaptopController(manageLaptopView, user);
                manageLaptopView.setVisible(true);
            }else if(e.getSource() == menuView.getBtnLogout()){
                int c = JOptionPane.showConfirmDialog(menuView, "Bạn có muốn đăng xuất không?", "Đăng xuất", JOptionPane.YES_NO_OPTION);
                if (c == JOptionPane.YES_OPTION) {
                    menuView.dispose();
                    LoginView loginView = new LoginView();
                    LoginController loginController = new LoginController(loginView);
                    loginView.setVisible(true);
                }
            }
        }
        
    }
    
}
