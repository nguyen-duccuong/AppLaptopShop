package applaptopshop.controllers;

import applaptopshop.daos.LaptopDAO;
import applaptopshop.daos.LaptopDAOImpl;
import applaptopshop.models.Laptop;
import applaptopshop.models.User;
import applaptopshop.utils.ButtonAddToCartEditor;
import applaptopshop.utils.ButtonRenderer;
import applaptopshop.utils.ImageRenderer;
import applaptopshop.utils.StaticData;
import applaptopshop.views.CartView;
import applaptopshop.views.ListLaptopView;
import applaptopshop.views.LoginView;
import applaptopshop.views.MenuView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class ListLaptopController {
    private final ListLaptopView listLaptopView;
    private final LaptopDAO laptopDAO;
    private final User user;

    public ListLaptopController(ListLaptopView listLaptopView, User user) {
        this.listLaptopView = listLaptopView;
        this.user = user;
        this.laptopDAO = new LaptopDAOImpl();
        this.listLaptopView.addListener(new ListLaptopListener());
        
        DefaultTableModel model = (DefaultTableModel) listLaptopView.getTableLaptop().getModel();
        model.setRowCount(0);
        
        List<Laptop> laptops = laptopDAO.findAll();
        
        if(laptops.size() > 0){
            listLaptopView.getTableLaptop().getColumnModel().getColumn(listLaptopView.getTableLaptop().getColumnCount() - 2).setCellRenderer(new ImageRenderer(50, 50));
            int row = 0;
            for(Laptop laptop: laptops){
                model.addRow(laptop.toObject(row + 1));
                ImageIcon image = new ImageIcon(laptop.getImage());
                listLaptopView.getTableLaptop().setValueAt(image, row, listLaptopView.getTableLaptop().getColumnCount() - 2);
                row++;
            }
            listLaptopView.getTableLaptop().getColumnModel().getColumn(listLaptopView.getTableLaptop().getColumnCount() - 1).setCellRenderer(new ButtonRenderer(StaticData.TEXT_ADD_TO_CART));
            listLaptopView.getTableLaptop().getColumnModel().getColumn(listLaptopView.getTableLaptop().getColumnCount() - 1).setCellEditor(new ButtonAddToCartEditor(new JTextField(StaticData.TEXT_ADD_TO_CART), laptops));
        }
    }
    
    class ListLaptopListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == listLaptopView.getBtnViewCart()){
                listLaptopView.dispose();
                CartView cartView = new CartView();
                CartController cartController = new CartController(cartView, user);
                cartView.setVisible(true);
            }else if(e.getSource() == listLaptopView.getBtnBackMenu()){
                listLaptopView.dispose();
                MenuView menuView = new MenuView();
                MenuController menuController = new MenuController(menuView, user);
                menuView.setVisible(true);
            }else if(e.getSource() == listLaptopView.getBtnLogout()){
                int c = JOptionPane.showConfirmDialog(listLaptopView, "Bạn có muốn đăng xuất không?", "Đăng xuất", JOptionPane.YES_NO_OPTION);
                if (c == JOptionPane.YES_OPTION) {
                    listLaptopView.dispose();
                    LoginView loginView = new LoginView();
                    LoginController loginController = new LoginController(loginView);
                    loginView.setVisible(true);
                }
            }
        }
    }
}
