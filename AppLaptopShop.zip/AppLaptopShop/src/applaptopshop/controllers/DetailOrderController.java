package applaptopshop.controllers;

import applaptopshop.models.Order;
import applaptopshop.models.OrderItem;
import applaptopshop.models.User;
import applaptopshop.utils.ImageRenderer;
import applaptopshop.views.DetailOrderView;
import applaptopshop.views.ListOrderView;
import applaptopshop.views.LoginView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class DetailOrderController {
    private final DetailOrderView detailOrderView;
    private final User user;
    private final Order order;

    public DetailOrderController(DetailOrderView detailOrderView, User user, Order order) {
        this.detailOrderView = detailOrderView;
        this.user = user;
        this.order = order;
        this.detailOrderView.addListener(new DetailOrderListener());
        
        if(order != null){
            DefaultTableModel model = (DefaultTableModel) detailOrderView.getTbOrderItem().getModel();
            model.setRowCount(0);
            detailOrderView.getTbOrderItem().getColumnModel().getColumn(detailOrderView.getTbOrderItem().getColumnCount() - 1).setCellRenderer(new ImageRenderer(50, 50));
            int row = 0;
            for(OrderItem orderItem: order.getOrderItems()){
                model.addRow(new Object[]{row + 1, orderItem.getLaptop().getName(), 
                    orderItem.getLaptop().getPrice(), orderItem.getQuantity(),
                    orderItem.getLaptop().getPrice() * orderItem.getQuantity()});
                ImageIcon image = new ImageIcon(orderItem.getLaptop().getImage());
                detailOrderView.getTbOrderItem().setValueAt(image, row, detailOrderView.getTbOrderItem().getColumnCount() - 1);
                row++;
            }
            
            detailOrderView.getTfOrderId().setText(order.getId().toString());
            detailOrderView.getTfOrderId().setEditable(false);
            detailOrderView.getTfPayment().setText(order.getPayment());
            detailOrderView.getTfPayment().setEditable(false);
            detailOrderView.getTfShipment().setText(order.getShipment());
            detailOrderView.getTfShipment().setEditable(false);
            detailOrderView.getTfCreatedAt().setText(new SimpleDateFormat("HH:mm:ss dd/MM/yyyy").format(order.getCreatedAt()));
            detailOrderView.getTfCreatedAt().setEditable(false);
            detailOrderView.getTfTotalMoney().setText(new DecimalFormat("##").format(order.getTotalMoney()));
            detailOrderView.getTfTotalMoney().setEditable(false);
        }
    }
    
    class DetailOrderListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == detailOrderView.getBtnListOrder()){
                detailOrderView.dispose();
                ListOrderView listOrderView = new ListOrderView();
                ListOrderController listOrderController = new ListOrderController(listOrderView, user);
                listOrderView.setVisible(true);
            }else if(e.getSource() == detailOrderView.getBtnLogout()){
                int c = JOptionPane.showConfirmDialog(detailOrderView, "Bạn có muốn đăng xuất không?", "Đăng xuất", JOptionPane.YES_NO_OPTION);
                if (c == JOptionPane.YES_OPTION) {
                    detailOrderView.dispose();
                    LoginView loginView = new LoginView();
                    LoginController loginController = new LoginController(loginView);
                    loginView.setVisible(true);
                }
            }
        }
        
    }
    
}
