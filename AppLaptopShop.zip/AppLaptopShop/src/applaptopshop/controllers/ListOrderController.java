package applaptopshop.controllers;

import applaptopshop.daos.OrderDAO;
import applaptopshop.daos.OrderDAOImpl;
import applaptopshop.models.Order;
import applaptopshop.models.User;
import applaptopshop.views.CartView;
import applaptopshop.views.DetailOrderView;
import applaptopshop.views.ListOrderView;
import applaptopshop.views.LoginView;
import applaptopshop.views.MenuView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ListOrderController {
    private final ListOrderView listOrderView;
    private final OrderDAO orderDAO;
    private final User user;

    public ListOrderController(ListOrderView listOrderView, User user) {
        this.listOrderView = listOrderView;
        this.user = user;
        this.orderDAO = new OrderDAOImpl();
        this.listOrderView.addListener(new ListOrderListener());
        
        List<Order> orders = orderDAO.findByUserId(user.getId());
        DefaultTableModel model = (DefaultTableModel) listOrderView.getTbOrder().getModel();
        model.setRowCount(0);
        
        if(orders.size() > 0){
            for(Order order: orders){
                model.addRow(new Object[]{order.getId(), new SimpleDateFormat("HH:mm:ss dd/MM/yyyy").format(order.getCreatedAt()), order.getTotalMoney()});
            }
            
            listOrderView.getTbOrder().addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int r = listOrderView.getTbOrder().getSelectedRow();
                    if(r >= 0){
                        Order order = orders.get(r);
                        listOrderView.dispose();
                        DetailOrderView detailOrderView = new DetailOrderView();
                        DetailOrderController detailOrderController = new DetailOrderController(detailOrderView, user, order);
                        detailOrderView.setVisible(true);
                    }
                }
            });
        }
    }
    
    class ListOrderListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == listOrderView.getBtnLogout()){
                int c = JOptionPane.showConfirmDialog(listOrderView, "Bạn có muốn đăng xuất không?", "Đăng xuất", JOptionPane.YES_NO_OPTION);
                if (c == JOptionPane.YES_OPTION) {
                    listOrderView.dispose();
                    LoginView loginView = new LoginView();
                    LoginController loginController = new LoginController(loginView);
                    loginView.setVisible(true);
                }
            }else if(e.getSource() == listOrderView.getBtnMenu()){
                listOrderView.dispose();
                MenuView menuView = new MenuView();
                MenuController menuController = new MenuController(menuView, user);
                menuView.setVisible(true);
            }else if(e.getSource() == listOrderView.getBtnViewCart()){
                listOrderView.dispose();
                CartView cartView = new CartView();
                CartController cartController = new CartController(cartView, user);
                cartView.setVisible(true);
            }
        }
        
    }
    
}
