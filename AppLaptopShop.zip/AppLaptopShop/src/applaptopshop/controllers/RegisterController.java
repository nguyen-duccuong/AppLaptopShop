package applaptopshop.controllers;

import applaptopshop.daos.UserDAO;
import applaptopshop.daos.UserDAOImpl;
import applaptopshop.models.User;
import applaptopshop.views.LoginView;
import applaptopshop.views.RegisterView;
import com.mysql.cj.util.StringUtils;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class RegisterController {
    private final RegisterView registerView;
    private final UserDAO userDAO;

    public RegisterController(RegisterView registerView) {
        this.registerView = registerView;
        this.userDAO = new UserDAOImpl();
        this.registerView.addListener(new RegisterListener());
    }
    
    class RegisterListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == registerView.getBtnRegister()){
                String username = registerView.getTfUsername().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(username)){
                    JOptionPane.showMessageDialog(registerView, "Tài khoản không được để trống!");
                    return;
                }
                String password = String.valueOf(registerView.getTfPassword().getPassword());
                if(StringUtils.isEmptyOrWhitespaceOnly(password)){
                    JOptionPane.showMessageDialog(registerView, "Mật khẩu không được để trống!");
                    return;
                }
                String fullName = registerView.getTfFullName().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(fullName)){
                    JOptionPane.showMessageDialog(registerView, "Tên không được để trống!");
                    return;
                }
                String email = registerView.getTfEmail().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(email)){
                    JOptionPane.showMessageDialog(registerView, "Email không được để trống!");
                    return;
                }
                String mobile = registerView.getTfMobile().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(mobile)){
                    JOptionPane.showMessageDialog(registerView, "Số điện thoại không được để trống!");
                    return;
                }
                String address = registerView.getTfAddress().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(address)){
                    JOptionPane.showMessageDialog(registerView, "Địa chỉ không được để trống!");
                    return;
                }
                if(userDAO.getByUsername(username) != null){
                    JOptionPane.showMessageDialog(registerView, "Tên tài khoản đã tồn tại!");
                    return;
                }
                User user = new User(username, password, fullName, email, mobile, address, "USER");
                boolean result = userDAO.insert(user);
                if(result){
                    JOptionPane.showMessageDialog(registerView, "Đăng ký thành công!");
                    registerView.dispose();
                    LoginView loginView = new LoginView();
                    LoginController loginController = new LoginController(loginView);
                    loginView.setVisible(true);
                }else{
                    JOptionPane.showMessageDialog(registerView, "Đăng ký thất bại!");
                }
            }else if(e.getSource() == registerView.getBtnLogin()){
                registerView.dispose();
                LoginView loginView = new LoginView();
                LoginController loginController = new LoginController(loginView);
                loginView.setVisible(true);
            }
        }
        
    }
    
}
