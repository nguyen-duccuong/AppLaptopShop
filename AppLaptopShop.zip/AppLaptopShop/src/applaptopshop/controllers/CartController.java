package applaptopshop.controllers;

import applaptopshop.daos.OrderDAO;
import applaptopshop.daos.OrderDAOImpl;
import applaptopshop.models.Laptop;
import applaptopshop.models.Order;
import applaptopshop.models.OrderItem;
import applaptopshop.models.User;
import applaptopshop.utils.ButtonRenderer;
import applaptopshop.utils.CartUtil;
import applaptopshop.utils.ImageRenderer;
import applaptopshop.utils.StaticData;
import applaptopshop.views.CartView;
import applaptopshop.views.ListLaptopView;
import applaptopshop.views.ListOrderView;
import applaptopshop.views.LoginView;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.DefaultCellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class CartController {
    private final CartView cartView;
    private final User user;
    private final OrderDAO orderDAO;

    public CartController(CartView cartView, User user) {
        this.cartView = cartView;
        this.user = user;
        this.orderDAO = new OrderDAOImpl();
        this.cartView.addListener(new CartListener());
        renderCart();
    }
    
    private void renderCart(){
        Map<Laptop, Integer> myCart = CartUtil.myCart;
        
        DefaultTableModel model = (DefaultTableModel) cartView.getTbCart().getModel();
        model.setRowCount(0);
        
        int totalNumber = 0;
        double totalMoney = 0;
        
        if(!myCart.isEmpty()){
            cartView.getTbCart().getColumnModel().getColumn(cartView.getTbCart().getColumnCount() - 4).setCellRenderer(new ImageRenderer(50, 50));
            int row = 0;
            for(Map.Entry<Laptop, Integer> entry: myCart.entrySet()){
                Laptop laptop = entry.getKey();
                int quantity = entry.getValue();
                totalNumber += quantity;
                totalMoney += quantity * laptop.getPrice();
                model.addRow(new Object[]{row + 1, laptop.getName(), laptop.getPrice(), quantity, quantity * laptop.getPrice()});
                ImageIcon image = new ImageIcon(laptop.getImage());
                cartView.getTbCart().setValueAt(image, row, cartView.getTbCart().getColumnCount() - 4);
                row++;
            }
            cartView.getTbCart().getColumnModel().getColumn(cartView.getTbCart().getColumnCount() - 3).setCellRenderer(new ButtonRenderer(StaticData.TEXT_INSCREASE));
            cartView.getTbCart().getColumnModel().getColumn(cartView.getTbCart().getColumnCount() - 3).setCellEditor(new ButtonIncreaseEditor(new JTextField(StaticData.TEXT_INSCREASE)));
            cartView.getTbCart().getColumnModel().getColumn(cartView.getTbCart().getColumnCount() - 2).setCellRenderer(new ButtonRenderer(StaticData.TEXT_REDUCE));
            cartView.getTbCart().getColumnModel().getColumn(cartView.getTbCart().getColumnCount() - 2).setCellEditor(new ButtonReduceEditor(new JTextField(StaticData.TEXT_REDUCE)));
            cartView.getTbCart().getColumnModel().getColumn(cartView.getTbCart().getColumnCount() - 1).setCellRenderer(new ButtonRenderer(StaticData.TEXT_REMOVE_FROM_CART));
            cartView.getTbCart().getColumnModel().getColumn(cartView.getTbCart().getColumnCount() - 1).setCellEditor(new ButtonRemoveFromCartEditor(new JTextField(StaticData.TEXT_REMOVE_FROM_CART)));
        
            cartView.getBtnOrder().setEnabled(true);
        }else{
            cartView.getBtnOrder().setEnabled(false);
        }
        
        cartView.getTfTotalNumber().setText(String.valueOf(totalNumber));
        cartView.getTfTotalNumber().setEditable(false);
        cartView.getTfTotalMoney().setText(new DecimalFormat("##").format(totalMoney));
        cartView.getTfTotalMoney().setEditable(false);
        
        cartView.getCbPayment().setModel(new DefaultComboBoxModel<>(StaticData.PAYMENT_TYPES.toArray()));
        cartView.getCbPayment().setSelectedIndex(0);
        cartView.getCbShipment().setModel(new DefaultComboBoxModel<>(StaticData.SHIPMENT_TYPES.toArray()));
        cartView.getCbShipment().setSelectedIndex(0);
    }
    
    class CartListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == cartView.getBtnListLaptop()){
                cartView.dispose();
                ListLaptopView listLaptopView = new ListLaptopView();
                ListLaptopController listLaptopController = new ListLaptopController(listLaptopView, user);
                listLaptopView.setVisible(true);
            }else if(e.getSource() == cartView.getBtnListOrder()){
                cartView.dispose();
                ListOrderView listOrderView = new ListOrderView();
                ListOrderController listOrderController = new ListOrderController(listOrderView, user);
                listOrderView.setVisible(true);
            }else if(e.getSource() == cartView.getBtnLogout()){
                int c = JOptionPane.showConfirmDialog(cartView, "Bạn có muốn đăng xuất không?", "Đăng xuất", JOptionPane.YES_NO_OPTION);
                if (c == JOptionPane.YES_OPTION) {
                    cartView.dispose();
                    LoginView loginView = new LoginView();
                    LoginController loginController = new LoginController(loginView);
                    loginView.setVisible(true);
                }
            }else if(e.getSource() == cartView.getBtnOrder()){
                int c = JOptionPane.showConfirmDialog(cartView, "Bạn có muốn đặt đơn hàng này không?", "Đặt hàng", JOptionPane.YES_NO_OPTION);
                if (c == JOptionPane.YES_OPTION) {
                    String payment = cartView.getCbPayment().getSelectedItem().toString();
                    String shipment = cartView.getCbShipment().getSelectedItem().toString();
                    double totalMoney = Double.parseDouble(cartView.getTfTotalMoney().getText());
                    List<OrderItem> orderItems = new ArrayList<>();
                    for(Map.Entry<Laptop, Integer> entry: CartUtil.myCart.entrySet()){
                        OrderItem orderItem = new OrderItem(entry.getKey(), entry.getValue());
                        orderItems.add(orderItem);
                    }
                    Order order = new Order(totalMoney, shipment, payment, user, orderItems);
                    boolean result = orderDAO.insert(order);
                    if (result) {
                        JOptionPane.showMessageDialog(cartView, "Thêm đơn hàng thành công!");
                        CartUtil.myCart = new LinkedHashMap<>();
                        cartView.dispose();
                        ListOrderView listOrderView = new ListOrderView();
                        ListOrderController listOrderController = new ListOrderController(listOrderView, user);
                        listOrderView.setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(cartView, "Thêm đơn hàng thất bại!");
                    }
                }
            }
        }
        
    }
    
    class ButtonIncreaseEditor extends DefaultCellEditor{
        private final JButton button;
        private int rowSelected;

        public ButtonIncreaseEditor(JTextField textField) {
            super(textField);
            button = new JButton();
            button.setOpaque(true);
            button.setText(textField.getText());
            button.addActionListener((ActionEvent e) -> {
                fireEditingStopped();
                List<Laptop> laptops = new ArrayList<>(CartUtil.myCart.keySet());
                Laptop laptop = laptops.get(rowSelected);
                CartUtil.myCart.put(laptop, CartUtil.myCart.get(laptop) + 1);
                renderCart();
            });
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            // Gán giá trị value cho button
            rowSelected = row;
            button.setText((value == null) ? "" : value.toString());
            return button;
        }

        @Override
        public boolean stopCellEditing(){
            return super.stopCellEditing();
        }

        @Override
        protected void fireEditingStopped(){
            super.fireEditingStopped();
        }
    }
    
    class ButtonReduceEditor extends DefaultCellEditor{
        private final JButton button;
        private int rowSelected;

        public ButtonReduceEditor(JTextField textField) {
            super(textField);
            button = new JButton();
            button.setOpaque(true);
            button.setText(textField.getText());
            button.addActionListener((ActionEvent e) -> {
                fireEditingStopped();
                List<Laptop> laptops = new ArrayList<>(CartUtil.myCart.keySet());
                Laptop laptop = laptops.get(rowSelected);
                if(CartUtil.myCart.get(laptop) > 1){
                    CartUtil.myCart.put(laptop, CartUtil.myCart.get(laptop) - 1);
                    renderCart();
                }else{
                    int c = JOptionPane.showConfirmDialog(null, "Bạn có muốn xóa sản phẩm này khỏi giỏ hàng không", "Xóa sản phẩm khỏi giỏ", JOptionPane.YES_NO_OPTION);
                    if (c == JOptionPane.YES_OPTION) {
                        CartUtil.myCart.remove(laptop);
                        renderCart();
                    }
                }
            });
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            // Gán giá trị value cho button
            rowSelected = row;
            button.setText((value == null) ? "" : value.toString());
            return button;
        }

        @Override
        public boolean stopCellEditing(){
            return super.stopCellEditing();
        }

        @Override
        protected void fireEditingStopped(){
            super.fireEditingStopped();
        }
    }
    
    class ButtonRemoveFromCartEditor extends DefaultCellEditor{
        private final JButton button;
        private int rowSelected;

        public ButtonRemoveFromCartEditor(JTextField textField) {
            super(textField);
            button = new JButton();
            button.setOpaque(true);
            button.setText(textField.getText());
            button.addActionListener((ActionEvent e) -> {
                fireEditingStopped();
                int c = JOptionPane.showConfirmDialog(null, "Bạn có muốn xóa sản phẩm này khỏi giỏ hàng không", "Xóa sản phẩm khỏi giỏ", JOptionPane.YES_NO_OPTION);
                if (c == JOptionPane.YES_OPTION) {
                    List<Laptop> laptops = new ArrayList<>(CartUtil.myCart.keySet());
                    Laptop laptop = laptops.get(rowSelected);
                    CartUtil.myCart.remove(laptop);
                    renderCart();
                }
            });
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            // Gán giá trị value cho button
            rowSelected = row;
            button.setText((value == null) ? "" : value.toString());
            return button;
        }

        @Override
        public boolean stopCellEditing(){
            return super.stopCellEditing();
        }

        @Override
        protected void fireEditingStopped(){
            super.fireEditingStopped();
        }
    }
    
}