package applaptopshop.controllers;

import applaptopshop.daos.LaptopDAO;
import applaptopshop.daos.LaptopDAOImpl;
import applaptopshop.models.Laptop;
import applaptopshop.models.User;
import applaptopshop.utils.StaticData;
import applaptopshop.views.ManageLaptopView;
import applaptopshop.views.UpdateLaptopView;
import com.mysql.cj.util.StringUtils;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.filechooser.FileNameExtensionFilter;

public class UpdateLaptopController {
    private final UpdateLaptopView updateLaptopView;
    private final LaptopDAO laptopDAO;
    private final Laptop laptop;
    private final User user;
    private File file;

    public UpdateLaptopController(UpdateLaptopView updateLaptopView, Laptop laptop, User user) {
        this.updateLaptopView = updateLaptopView;
        this.laptop = laptop;
        this.user = user;
        this.laptopDAO = new LaptopDAOImpl();
        this.updateLaptopView.addListener(new UpdateLaptopListener());
        
        if(laptop == null){
            updateLaptopView.dispose();
            ManageLaptopView manageLaptopView = new ManageLaptopView();
            ManageLaptopController manageLaptopController = new ManageLaptopController(manageLaptopView, user);
            manageLaptopView.setVisible(true);
        }else{
            updateLaptopView.getTfName().setText(laptop.getName());
            updateLaptopView.getTfRam().setText(laptop.getRam());
            updateLaptopView.getTfCapacity().setText(laptop.getCapacity());
            updateLaptopView.getTfCPU().setText(laptop.getCpu());
            updateLaptopView.getTfManu().setText(laptop.getManufacturer());
            updateLaptopView.getTfScreen().setText(laptop.getScreen());
            updateLaptopView.getTfPrice().setText(String.valueOf(laptop.getPrice()));
            file = new File(laptop.getImage());
            updateLaptopView.getLbNameImage().setText(laptop.getImage().substring(laptop.getImage().lastIndexOf("/") + 1));
            ImageIcon imageIcon = new ImageIcon(laptop.getImage());
            Image image = imageIcon.getImage();
            Image scaledImage = image.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            ImageIcon scaledImageIcon = new ImageIcon(scaledImage);
            updateLaptopView.getLbImage().setIcon(scaledImageIcon);
            updateLaptopView.getLbImage().setHorizontalAlignment(SwingConstants.CENTER);
        }
        
    }
    
    class UpdateLaptopListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == updateLaptopView.getBtnEdit()){
                String name = updateLaptopView.getTfName().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(name)){
                    JOptionPane.showMessageDialog(updateLaptopView, "Laptop không để trống!");
                    return;
                }
                String manu = updateLaptopView.getTfManu().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(manu)){
                    JOptionPane.showMessageDialog(updateLaptopView, "Hãng laptop không để trống!");
                    return;
                }
                String ram = updateLaptopView.getTfRam().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(ram)){
                    JOptionPane.showMessageDialog(updateLaptopView, "Ram laptop không để trống!");
                    return;
                }
                String capacity = updateLaptopView.getTfCapacity().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(capacity)){
                    JOptionPane.showMessageDialog(updateLaptopView, "Dung lượng laptop không để trống!");
                    return;
                }
                String cpu = updateLaptopView.getTfCPU().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(cpu)){
                    JOptionPane.showMessageDialog(updateLaptopView, "CPI laptop không để trống!");
                    return;
                }
                String screen = updateLaptopView.getTfScreen().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(screen)){
                    JOptionPane.showMessageDialog(updateLaptopView, "Màn hình laptop không để trống!");
                    return;
                }
                if(StringUtils.isEmptyOrWhitespaceOnly(updateLaptopView.getTfPrice().getText())){
                    JOptionPane.showMessageDialog(updateLaptopView, "Giá laptop không để trống!");
                    return;
                }
                Double price = 0.0;
                try {
                    price = Double.parseDouble(updateLaptopView.getTfPrice().getText());
                    if(price <= 0 ){
                        JOptionPane.showMessageDialog(updateLaptopView, "Giá laptop lớn hơn 0!");
                        return;
                    }
                } catch (NumberFormatException ee) {
                    JOptionPane.showMessageDialog(updateLaptopView, "Giá laptop chỉ gồm số!");
                }
                if(file == null){
                    JOptionPane.showMessageDialog(updateLaptopView, "Chưa chọn hình ảnh laptop!");
                    return;
                }
                String source = StaticData.LOCATION_SAVE_FILE + "/" + file.getName();
                try (FileInputStream sourceFile = new FileInputStream(file.getAbsoluteFile());
                        FileOutputStream destinationFile = new FileOutputStream(source)) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = sourceFile.read(buffer)) != -1) {
                        destinationFile.write(buffer, 0, bytesRead);
                    }
                } catch (IOException ee) {
                    JOptionPane.showMessageDialog(updateLaptopView, "Upload file thất bại!");
                    return;
                }
                laptop.setName(name);
                laptop.setRam(ram);
                laptop.setCapacity(capacity);
                laptop.setManufacturer(manu);
                laptop.setCpu(cpu);
                laptop.setScreen(screen);
                laptop.setPrice(price);
                laptop.setImage(source);
                boolean result = laptopDAO.update(laptop);
                if (result) {
                    JOptionPane.showMessageDialog(updateLaptopView, "Cập nhật laptop thành công!");
                    updateLaptopView.dispose();
                    ManageLaptopView manageLaptopView = new ManageLaptopView();
                    ManageLaptopController manageLaptopController = new ManageLaptopController(manageLaptopView, user);
                    manageLaptopView.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(updateLaptopView, "Cập nhật laptop thất bại!");
                }
            }else if(e.getSource() == updateLaptopView.getBtnBack()){
                updateLaptopView.dispose();
                ManageLaptopView manageLaptopView = new ManageLaptopView();
                ManageLaptopController manageLaptopController = new ManageLaptopController(manageLaptopView, user);
                manageLaptopView.setVisible(true);
            }else if(e.getSource() == updateLaptopView.getBtnChooseImage()){
                JFileChooser fileChooser = new JFileChooser();
                FileNameExtensionFilter imageFilter = new FileNameExtensionFilter("Image Files", "jpg", "jpeg", "png", "gif");
                fileChooser.setFileFilter(imageFilter);
                int r = fileChooser.showSaveDialog(null);
                if (r == JFileChooser.APPROVE_OPTION) {
                    file = fileChooser.getSelectedFile();
                    updateLaptopView.getLbNameImage().setText(file.getName());
                    ImageIcon imageIcon = new ImageIcon(file.getAbsolutePath());
                    Image image = imageIcon.getImage();
                    Image scaledImage = image.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                    ImageIcon scaledImageIcon = new ImageIcon(scaledImage);
                    updateLaptopView.getLbImage().setIcon(scaledImageIcon);
                    updateLaptopView.getLbImage().setHorizontalAlignment(SwingConstants.CENTER);
                }
            }
        }   
    }
}
