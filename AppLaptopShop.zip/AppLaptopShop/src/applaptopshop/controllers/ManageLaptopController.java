package applaptopshop.controllers;

import applaptopshop.daos.LaptopDAO;
import applaptopshop.daos.LaptopDAOImpl;
import applaptopshop.models.Laptop;
import applaptopshop.models.User;
import applaptopshop.utils.ImageRenderer;
import applaptopshop.views.AddLaptopView;
import applaptopshop.views.ManageLaptopView;
import applaptopshop.views.MenuView;
import applaptopshop.views.UpdateLaptopView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;

public class ManageLaptopController {
    private final ManageLaptopView manageLaptopView;
    private final LaptopDAO laptopDAO;
    private final User user;

    public ManageLaptopController(ManageLaptopView manageLaptopView, User user) {
        this.manageLaptopView = manageLaptopView;
        this.user = user;
        this.laptopDAO = new LaptopDAOImpl();
        this.manageLaptopView.addListener(new ManageLaptopListener());
        
        DefaultTableModel model = (DefaultTableModel) manageLaptopView.getTableLaptop().getModel();
        model.setRowCount(0);
        
        List<Laptop> laptops = laptopDAO.findAll();
        
        if(laptops.size() > 0){
            manageLaptopView.getTableLaptop().getColumnModel().getColumn(manageLaptopView.getTableLaptop().getColumnCount() - 1).setCellRenderer(new ImageRenderer(50, 50));
            int row = 0;
            for(Laptop laptop: laptops){
                model.addRow(laptop.toObject(row + 1));
                ImageIcon image = new ImageIcon(laptop.getImage());
                manageLaptopView.getTableLaptop().setValueAt(image, row, manageLaptopView.getTableLaptop().getColumnCount() - 1);
                row++;
            }
            
            manageLaptopView.getTableLaptop().addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int r = manageLaptopView.getTableLaptop().getSelectedRow();
                    if(r >= 0){
                        Laptop laptop = laptops.get(r);
                        manageLaptopView.dispose();
                        UpdateLaptopView updateLaptopView = new UpdateLaptopView();
                        UpdateLaptopController updateLaptopController = new UpdateLaptopController(updateLaptopView, laptop, user);
                        updateLaptopView.setVisible(true);
                    }
                }
            });
        }
    }

    class ManageLaptopListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == manageLaptopView.getBtnAddLaptop()){
                manageLaptopView.dispose();
                AddLaptopView addLaptopView = new AddLaptopView();
                AddLaptopController addLaptopController = new AddLaptopController(addLaptopView, user);
                addLaptopView.setVisible(true);
            }else if(e.getSource() == manageLaptopView.getBtnBack()){
                manageLaptopView.dispose();
                MenuView menuView = new MenuView();
                MenuController menuController = new MenuController(menuView, user);
                menuView.setVisible(true);
            }
        }
    }
    
    
}
