package applaptopshop.controllers;

import applaptopshop.daos.UserDAO;
import applaptopshop.daos.UserDAOImpl;
import applaptopshop.models.User;
import applaptopshop.utils.CartUtil;
import applaptopshop.views.LoginView;
import applaptopshop.views.MenuView;
import applaptopshop.views.RegisterView;
import com.mysql.cj.util.StringUtils;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedHashMap;
import javax.swing.JOptionPane;

public class LoginController {
    private final LoginView loginView;
    private final UserDAO userDAO;

    public LoginController(LoginView loginView) {
        this.loginView = loginView;
        this.userDAO = new UserDAOImpl();
        this.loginView.addListener(new LoginListener());
    }
    
    class LoginListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == loginView.getBtnLogin()){
                String username = loginView.getTfUsername().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(username)){
                    JOptionPane.showMessageDialog(loginView, "Vui lòng nhập tài khoản!");
                    return;
                }
                String password = String.valueOf(loginView.getTfPassword().getPassword());
                if(StringUtils.isEmptyOrWhitespaceOnly(password)){
                    JOptionPane.showMessageDialog(loginView, "Vui lòng nhập mật khẩu!");
                    return;
                }
                User user = userDAO.login(username, password);
                if(user == null){
                    JOptionPane.showMessageDialog(loginView, "Sai thông tin tài khoản hoặc mật khẩu!");
                }else{
                    CartUtil.myCart = new LinkedHashMap<>();
                    loginView.dispose();
                    MenuView menuView = new MenuView();
                    MenuController menuController = new MenuController(menuView, user);
                    menuView.setVisible(true);
                }
            }else if(e.getSource() == loginView.getBtnRegister()){
                loginView.dispose();
                RegisterView registerView = new RegisterView();
                RegisterController registerController = new RegisterController(registerView);
                registerView.setVisible(true);
            }
        }
        
    }
    
}
