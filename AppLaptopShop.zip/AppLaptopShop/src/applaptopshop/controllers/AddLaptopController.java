package applaptopshop.controllers;

import applaptopshop.daos.LaptopDAO;
import applaptopshop.daos.LaptopDAOImpl;
import applaptopshop.models.Laptop;
import applaptopshop.models.User;
import applaptopshop.utils.StaticData;
import applaptopshop.views.AddLaptopView;
import applaptopshop.views.ManageLaptopView;
import com.mysql.cj.util.StringUtils;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.filechooser.FileNameExtensionFilter;

public class AddLaptopController {
    
    private final AddLaptopView addLaptopView;
    private final LaptopDAO laptopDAO;
    private final User user;
    
    private File file;
    

    public AddLaptopController(AddLaptopView addLaptopView, User user) {
        this.addLaptopView = addLaptopView;
        this.user = user;
        this.laptopDAO = new LaptopDAOImpl();
        this.addLaptopView.addListener(new AddLaptopListener());
    }
    
    class AddLaptopListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == addLaptopView.getBtnAdd()){
                String name = addLaptopView.getTfName().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(name)){
                    JOptionPane.showMessageDialog(addLaptopView, "Laptop không để trống!");
                    return;
                }
                String manu = addLaptopView.getTfManu().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(manu)){
                    JOptionPane.showMessageDialog(addLaptopView, "Hãng laptop không để trống!");
                    return;
                }
                String ram = addLaptopView.getTfRam().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(ram)){
                    JOptionPane.showMessageDialog(addLaptopView, "Ram laptop không để trống!");
                    return;
                }
                String capacity = addLaptopView.getTfCapacity().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(capacity)){
                    JOptionPane.showMessageDialog(addLaptopView, "Dung lượng laptop không để trống!");
                    return;
                }
                String cpu = addLaptopView.getTfCPU().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(cpu)){
                    JOptionPane.showMessageDialog(addLaptopView, "CPI laptop không để trống!");
                    return;
                }
                String screen = addLaptopView.getTfScreen().getText();
                if(StringUtils.isEmptyOrWhitespaceOnly(screen)){
                    JOptionPane.showMessageDialog(addLaptopView, "Màn hình laptop không để trống!");
                    return;
                }
                if(StringUtils.isEmptyOrWhitespaceOnly(addLaptopView.getTfPrice().getText())){
                    JOptionPane.showMessageDialog(addLaptopView, "Giá laptop không để trống!");
                    return;
                }
                Double price = 0.0;
                try {
                    price = Double.parseDouble(addLaptopView.getTfPrice().getText());
                    if(price <= 0 ){
                        JOptionPane.showMessageDialog(addLaptopView, "Giá laptop lớn hơn 0!");
                        return;
                    }
                } catch (NumberFormatException ee) {
                    JOptionPane.showMessageDialog(addLaptopView, "Giá laptop chỉ gồm số!");
                }
                if(file == null){
                    JOptionPane.showMessageDialog(addLaptopView, "Chưa chọn hình ảnh laptop!");
                    return;
                }
                String source = StaticData.LOCATION_SAVE_FILE + "/" + file.getName();
                try (FileInputStream sourceFile = new FileInputStream(file.getAbsoluteFile());
                        FileOutputStream destinationFile = new FileOutputStream(source)) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = sourceFile.read(buffer)) != -1) {
                        destinationFile.write(buffer, 0, bytesRead);
                    }
                } catch (IOException ee) {
                    JOptionPane.showMessageDialog(addLaptopView, "Upload file thất bại!");
                    return;
                }
                Laptop laptop = new Laptop(name, ram, capacity, manu, cpu, screen, price, source);
                boolean result = laptopDAO.insert(laptop);
                if (result) {
                    JOptionPane.showMessageDialog(addLaptopView, "Thêm laptop thành công!");
                    addLaptopView.dispose();
                    ManageLaptopView manageLaptopView = new ManageLaptopView();
                    ManageLaptopController manageLaptopController = new ManageLaptopController(manageLaptopView, user);
                    manageLaptopView.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(addLaptopView, "Thêm laptop thất bại!");
                }
            }else if(e.getSource() == addLaptopView.getBtnBack()){
                addLaptopView.dispose();
                ManageLaptopView manageLaptopView = new ManageLaptopView();
                ManageLaptopController manageLaptopController = new ManageLaptopController(manageLaptopView, user);
                manageLaptopView.setVisible(true);
            }else if(e.getSource() == addLaptopView.getBtnChooseImage()){
                JFileChooser fileChooser = new JFileChooser();
                FileNameExtensionFilter imageFilter = new FileNameExtensionFilter("Image Files", "jpg", "jpeg", "png", "gif");
                fileChooser.setFileFilter(imageFilter);
                int r = fileChooser.showSaveDialog(null);
                if (r == JFileChooser.APPROVE_OPTION) {
                    file = fileChooser.getSelectedFile();
                    addLaptopView.getLbNameImage().setText(file.getName());
                    ImageIcon imageIcon = new ImageIcon(file.getAbsolutePath());
                    Image image = imageIcon.getImage();
                    Image scaledImage = image.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                    ImageIcon scaledImageIcon = new ImageIcon(scaledImage);
                    addLaptopView.getLbImage().setIcon(scaledImageIcon);
                    addLaptopView.getLbImage().setHorizontalAlignment(SwingConstants.CENTER);
                }
            }
        }
    }
    
}
