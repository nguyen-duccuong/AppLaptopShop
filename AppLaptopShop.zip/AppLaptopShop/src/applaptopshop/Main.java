package applaptopshop;

import applaptopshop.controllers.LoginController;
import applaptopshop.views.LoginView;


public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LoginView loginView = new LoginView();
        LoginController loginController = new LoginController(loginView);
        loginView.setVisible(true);
    }
    
}
