package applaptopshop.utils;

import applaptopshop.models.Laptop;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.util.List;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class ButtonAddToCartEditor extends DefaultCellEditor{
    private final JButton button;
    private final List<Laptop> laptops;
    private int rowSelected;

    public ButtonAddToCartEditor(JTextField textField, List<Laptop> laptops) {
        super(textField);
        this.laptops = laptops;
        button = new JButton();
        button.setOpaque(true);
        button.setText(textField.getText());
        button.addActionListener((ActionEvent e) -> {
            fireEditingStopped();
            Laptop laptop = (Laptop) getCellEditorValue();
            if(CartUtil.myCart.containsKey(laptop)){
                CartUtil.myCart.put(laptop, CartUtil.myCart.get(laptop) + 1);
            }else{
                CartUtil.myCart.put(laptop, 1);
            }
            JOptionPane.showMessageDialog(null, "Thêm " + laptop.getName() + " vào giỏ thành công!");
        });
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        // Gán giá trị value cho button
        rowSelected = row;
        button.setText((value == null) ? "" : value.toString());
        return button;
    }
    
    @Override
    public Object getCellEditorValue(){
        return laptops.get(rowSelected);
    }
    
    @Override
    public boolean stopCellEditing(){
        return super.stopCellEditing();
    }
    
    @Override
    protected void fireEditingStopped(){
        super.fireEditingStopped();
    }
}
