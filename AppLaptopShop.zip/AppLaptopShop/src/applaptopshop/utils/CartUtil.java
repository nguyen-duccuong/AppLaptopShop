package applaptopshop.utils;

import applaptopshop.models.Laptop;
import java.util.Map;

public class CartUtil {
    public static Map<Laptop, Integer> myCart;
}
