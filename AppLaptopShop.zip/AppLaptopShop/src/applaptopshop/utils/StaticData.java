package applaptopshop.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StaticData {
    public static final List<String> PAYMENT_TYPES = Arrays.asList("Thanh toán trực tiếp", "Paypal", "Thẻ ngân hàng");
    public static final List<String> SHIPMENT_TYPES = Arrays.asList("Vận chuyển nhanh", "Giao hàng tiết kiệm", "Hỏa tốc");
    public static final String TEXT_ADD_TO_CART = "Thêm";
    public static final String TEXT_INSCREASE = "Tăng";
    public static final String TEXT_REDUCE = "Giảm";
    public static final String TEXT_REMOVE_FROM_CART = "Xóa";
    public static final String LOCATION_SAVE_FILE = "/home/cuongpham/Desktop/ExternalProject/";
}
