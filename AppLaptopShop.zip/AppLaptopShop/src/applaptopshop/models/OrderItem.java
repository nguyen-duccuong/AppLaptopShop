package applaptopshop.models;

public class OrderItem {
    private Long id;
    private Laptop laptop;
    private Integer quantity;

    public OrderItem(Laptop laptop, Integer quantity) {
        this.laptop = laptop;
        this.quantity = quantity;
    }

    public OrderItem() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Laptop getLaptop() {
        return laptop;
    }

    public void setLaptop(Laptop laptop) {
        this.laptop = laptop;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
    
}
