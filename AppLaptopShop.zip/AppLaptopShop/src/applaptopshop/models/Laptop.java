package applaptopshop.models;

import java.util.Objects;

public class Laptop {
    private Long id;
    private String name;
    private String ram;
    private String capacity;
    private String manufacturer;
    private String cpu;
    private String screen;
    private Double price;
    private String image;

    public Laptop(String name, String ram, String capacity, String manufacturer, String cpu, String screen, Double price, String image) {
        this.name = name;
        this.ram = ram;
        this.capacity = capacity;
        this.manufacturer = manufacturer;
        this.cpu = cpu;
        this.screen = screen;
        this.price = price;
        this.image = image;
    }

    public Laptop() {
        
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRam() {
        return ram;
    }

    public void setRam(String ram) {
        this.ram = ram;
    }

    public String getCapacity() {
        return capacity;
    }

    public void setCapacity(String capacity) {
        this.capacity = capacity;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public String getScreen() {
        return screen;
    }

    public void setScreen(String screen) {
        this.screen = screen;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
    
    public Object[] toObject(int index) {
        return new Object[]{index, name, manufacturer, ram, capacity, cpu, screen, price};
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Laptop other = (Laptop) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }
    
    
}
