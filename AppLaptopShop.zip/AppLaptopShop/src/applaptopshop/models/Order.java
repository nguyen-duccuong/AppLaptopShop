package applaptopshop.models;

import java.util.Date;
import java.util.List;

public class Order {
    private Long id;
    private Double totalMoney;
    private String shipment;
    private String payment;
    private User user;
    private List<OrderItem> orderItems;
    private Date createdAt;

    public Order(Double totalMoney, String shipment, String payment, User user, List<OrderItem> orderItems) {
        this.totalMoney = totalMoney;
        this.shipment = shipment;
        this.payment = payment;
        this.user = user;
        this.orderItems = orderItems;
        this.createdAt = new Date();
    }

    public Order() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(Double totalMoney) {
        this.totalMoney = totalMoney;
    }

    public String getShipment() {
        return shipment;
    }

    public void setShipment(String shipment) {
        this.shipment = shipment;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<OrderItem> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(List<OrderItem> orderItems) {
        this.orderItems = orderItems;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
    
}
