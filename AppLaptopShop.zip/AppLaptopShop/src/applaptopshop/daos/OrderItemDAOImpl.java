package applaptopshop.daos;

import applaptopshop.models.OrderItem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class OrderItemDAOImpl implements OrderItemDAO{
    private final Connection conn = MySQLConnection.getMySQLConnection();

    @Override
    public boolean insert(OrderItem orderItem, Long orderId) {
        String sql = "INSERT INTO order_items (quantity, laptop_id, order_id) VALUES (?, ?, ?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, orderItem.getQuantity());
            ps.setLong(2, orderItem.getLaptop().getId());
            ps.setLong(3, orderId);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public List<OrderItem> findByOrderId(Long order_id) {
        List<OrderItem> orderItems = new ArrayList<>();
        String sql = "SELECT * FROM order_items WHERE order_id = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, order_id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                OrderItem orderItem = new OrderItem();
                orderItem.setId(rs.getLong("id"));
                orderItem.setQuantity(rs.getInt("quantity"));
                orderItem.setLaptop(new LaptopDAOImpl().findById(rs.getLong("laptop_id")));
                orderItems.add(orderItem);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderItems;
    }
}
