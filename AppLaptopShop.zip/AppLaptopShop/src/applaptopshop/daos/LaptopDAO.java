package applaptopshop.daos;

import applaptopshop.models.Laptop;
import java.util.List;

public interface LaptopDAO {
    List<Laptop> findAll();
    boolean insert(Laptop laptop);
    boolean update(Laptop laptop);
    Laptop findById(Long id);
}
