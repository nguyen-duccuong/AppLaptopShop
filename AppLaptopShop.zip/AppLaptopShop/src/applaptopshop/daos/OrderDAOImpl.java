package applaptopshop.daos;

import applaptopshop.models.Order;
import applaptopshop.models.OrderItem;
import applaptopshop.models.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class OrderDAOImpl implements OrderDAO{
    private final Connection conn = MySQLConnection.getMySQLConnection();
    private OrderItemDAO orderItemDAO;
    public OrderDAOImpl(){
        orderItemDAO = new OrderItemDAOImpl();
    }

    @Override
    public boolean insert(Order order) {
        String sql = "INSERT INTO orders (total_money, shipment, payment, created_at, user_id) VALUES (?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setDouble(1, order.getTotalMoney());
            ps.setString(2, order.getShipment());
            ps.setString(3, order.getPayment());
            ps.setTimestamp(4, new java.sql.Timestamp(order.getCreatedAt().getTime()));
            ps.setLong(5, order.getUser().getId());

            ps.executeUpdate();
            
            ResultSet rs = ps.getGeneratedKeys();
            if(rs.next()){
                Long orderId = rs.getLong(1);
                for(OrderItem orderItem: order.getOrderItems()){
                    if(!orderItemDAO.insert(orderItem, orderId)){
                        return false;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public List<Order> findByUserId(Long userId) {
        String sql = "SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC ";
        List<Order> orders = new ArrayList<>();
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, userId);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Order order = new Order();
                order.setId(rs.getLong("id"));
                order.setShipment(rs.getString("shipment"));
                order.setPayment(rs.getString("payment"));
                order.setTotalMoney(rs.getDouble("total_money"));
                order.setCreatedAt(rs.getTimestamp("created_at"));
                User user = new User();
                user.setId(userId);
                order.setUser(user);
                List<OrderItem> orderItems = orderItemDAO.findByOrderId(order.getId());
                order.setOrderItems(orderItems);
                
                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }
}
