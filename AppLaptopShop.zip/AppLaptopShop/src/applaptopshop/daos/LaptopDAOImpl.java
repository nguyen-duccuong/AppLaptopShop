package applaptopshop.daos;

import applaptopshop.models.Laptop;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class LaptopDAOImpl implements LaptopDAO{
    private final Connection conn = MySQLConnection.getMySQLConnection();

    @Override
    public List<Laptop> findAll() {
        String sql = "SELECT * FROM laptops";
        List<Laptop> laptops = new ArrayList<>();
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Laptop laptop = new Laptop();
                laptop.setId(rs.getLong("id"));
                laptop.setName(rs.getString("name"));
                laptop.setRam(rs.getString("ram"));
                laptop.setCapacity(rs.getString("capacity"));
                laptop.setManufacturer(rs.getString("manufacturer"));
                laptop.setCpu(rs.getString("cpu"));
                laptop.setScreen(rs.getString("screen"));
                laptop.setPrice(rs.getDouble("price"));
                laptop.setImage(rs.getString("image"));
                
                laptops.add(laptop);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return laptops;
    }

    @Override
    public boolean insert(Laptop laptop) {
        String sql = "INSERT INTO laptops (name, ram, capacity, manufacturer, cpu, screen, price, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, laptop.getName());
            ps.setString(2, laptop.getRam());
            ps.setString(3, laptop.getCapacity());
            ps.setString(4, laptop.getManufacturer());
            ps.setString(5, laptop.getCpu());
            ps.setString(6, laptop.getScreen());
            ps.setDouble(7, laptop.getPrice());
            ps.setString(8, laptop.getImage());

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public boolean update(Laptop laptop) {
        String sql = "UPDATE laptops SET name = ?, ram = ?, capacity = ?, manufacturer = ?, cpu = ?, screen = ?, price = ?, image = ? WHERE id = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, laptop.getName());
            ps.setString(2, laptop.getRam());
            ps.setString(3, laptop.getCapacity());
            ps.setString(4, laptop.getManufacturer());
            ps.setString(5, laptop.getCpu());
            ps.setString(6, laptop.getScreen());
            ps.setDouble(7, laptop.getPrice());
            ps.setString(8, laptop.getImage());
            ps.setLong(9, laptop.getId());
            
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public Laptop findById(Long id) {
        String sql = "SELECT * FROM laptops WHERE id = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Laptop laptop = new Laptop();
                laptop.setId(rs.getLong("id"));
                laptop.setName(rs.getString("name"));
                laptop.setRam(rs.getString("ram"));
                laptop.setCapacity(rs.getString("capacity"));
                laptop.setManufacturer(rs.getString("manufacturer"));
                laptop.setCpu(rs.getString("cpu"));
                laptop.setScreen(rs.getString("screen"));
                laptop.setPrice(rs.getDouble("price"));
                laptop.setImage(rs.getString("image"));
                return laptop;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        return null;
    }
    
}
