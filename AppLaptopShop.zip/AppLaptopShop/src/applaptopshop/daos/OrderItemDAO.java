package applaptopshop.daos;

import applaptopshop.models.OrderItem;
import java.util.List;

public interface OrderItemDAO {
    boolean insert(OrderItem orderItem, Long orderId);
    List<OrderItem> findByOrderId(Long id);
}
