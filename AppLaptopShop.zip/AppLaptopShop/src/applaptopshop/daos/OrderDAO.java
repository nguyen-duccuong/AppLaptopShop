package applaptopshop.daos;

import applaptopshop.models.Order;
import java.util.List;

public interface OrderDAO {
    boolean insert(Order order);
    List<Order> findByUserId(Long userId);
}
