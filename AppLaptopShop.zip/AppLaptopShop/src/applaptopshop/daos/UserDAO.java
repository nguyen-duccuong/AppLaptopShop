package applaptopshop.daos;

import applaptopshop.models.User;

public interface UserDAO {
    boolean insert(User user);
    User getByUsername(String username);
    User login(String username, String password);
}
